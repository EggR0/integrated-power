# Local LLM Mode Contract

**Script**: `scripts/Invoke-vLLMJob.ps1`

## Purpose
Use a local OpenAI-compatible vLLM endpoint for token-efficient preprocessing, summarization, extraction, and low-risk draft generation.

## Use When

- The task involves large or noisy text that should be compressed before Codex sees it.
- The user explicitly asks for local LLM, vLLM, offline model, or local preprocessing.
- The expected output is a report, summary, checklist, classification, or extracted data that can be verified locally.
- Cloud quota should be conserved.

## Avoid When

- The task requires direct code edits with high correctness risk.
- The local endpoint is offline and the user needs a finished implementation now.
- The task involves sensitive credentials or deployment actions.

## Usage

- Provide the instruction via `-PromptFile`.
- Optionally pass `-Endpoint`; bare URLs are normalized to `/v1`.
- Optionally pass `-Model`; if omitted, the script queries `/v1/models`.
- Use `VLLM_BASE_URL` and `VLLM_API_KEY` when needed.

## Output

- The final local LLM response is written to `-OutputFile` or globalStorage `reports/vllm-<stamp>.md`.
- Token and timing metrics are appended to globalStorage `reports/token_usage.csv` and `reports/local_llm_metrics.csv` when usage data is available.

## Fallback

If the local endpoint is offline, record that in the artifact and choose either Main Agent Direct or Codex depending on the task's risk and complexity.
