# Codex Orchestrator Plugin

This Antigravity Plugin globally installs a single **AI work router** skill.
It decides whether work should stay with the main agent, be delegated to OpenAI Codex, or be preprocessed by a local OpenAI-compatible vLLM endpoint.

## Installation
1. Drop this folder (`codex-orchestrator-plugin`) into `~/.gemini/config/plugins/`.
2. Ensure you have the `codex.exe` CLI installed either globally on your `PATH`, or set `$env:CODEX_EXE`. The plugin will also attempt to auto-detect installations inside `%LOCALAPPDATA%\OpenAI\Codex\bin`. If it still cannot find it, it will prompt you interactively in the console.

## Global Routing Rules (Optional)
To ensure Antigravity automatically uses this plugin for large architectural decisions and refactors, you should append the recommended routing rules to your `~/.gemini/GEMINI.md` file. 

You can do this automatically by running:
```powershell
& "~/.gemini/config/plugins/codex-orchestrator-plugin/install/Add-GlobalRules.ps1"
```

## Features
- **Single Skill, No Duplicates**: Installs only `codex-orchestrator`; stale skills from older releases are removed by the extension installer.
- **Token-Efficient Routing**: Chooses main-agent direct work, Codex delegation, or local vLLM preprocessing based on task shape.
- **Watchdog Protection**: Codex jobs run with strict UTF-8 stream handling and a hang-protection watchdog.
- **Local LLM Mode**: Uses `Invoke-vLLMJob.ps1` for local OpenAI-compatible summarization, extraction, and preprocessing.
- **Portability**: Auto-resolves Codex binary locations.
- **Debate Mode**: Transparent reasoning with persistent Markdown transcripts.
