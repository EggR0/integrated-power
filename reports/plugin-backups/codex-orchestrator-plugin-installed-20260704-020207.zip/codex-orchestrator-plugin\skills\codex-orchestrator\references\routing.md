# Routing Contract

## Purpose
Choose the lowest-cost reliable execution route before spending large cloud context.

## Decision Order

1. **Main Agent Direct**
   - Use for small, obvious edits; short explanations; local file inspection; command checks; packaging; verification; and glue work.
   - Prefer this when the task can be completed quickly with local tools and does not need a second model.

2. **Local LLM / vLLM**
   - Use for broad summarization, preprocessing, extraction, deduplication, clustering, noisy-context reduction, draft checklists, and other low-risk transformations.
   - Prefer this before Codex when the input is large and the output can be verified locally.
   - Use `scripts/Invoke-vLLMJob.ps1`.

3. **Codex Debate**
   - Use for architecture decisions, ambiguous structural changes, tradeoff review, second opinions, and read-only critique.
   - Use `scripts/Invoke-CodexDebate.ps1`.

4. **Codex Job**
   - Use for bounded implementation, difficult code review, test generation, refactors, or direct edits that need strong coding judgment.
   - Use `scripts/Invoke-CodexJob.ps1`.

5. **Work Window**
   - Use when the task is a supervised queue/calendar/context dispatch that may choose among multiple pending tasks.
   - Use `scripts/Invoke-AiWorkWindow.ps1`.

## Required Behavior

- Do not wait for the user to name a backend if the task clearly benefits from delegation.
- If the user explicitly names Codex or local LLM, honor that choice unless it is unavailable or unsafe.
- If local LLM is unavailable, note that fact and choose Main Agent Direct or Codex based on risk.
- If Codex Debate fails, times out, or returns an inconclusive result, fall back to Main Agent Direct for a narrow next step or ask Codex Job only when the implementation boundary is clear.
- If Codex quota should be conserved, use local LLM for preprocessing where practical.
- Keep file contents out of prompts when paths are sufficient.
- Always leave an artifact under globalStorage `reports/` or `discussions/`, or summarize the direct local change.
- Record the chosen route and reason in the artifact whenever delegation is used. Include why cheaper local preprocessing was or was not used.

## Token Efficiency Checks

- Before Codex: ask whether local LLM can reduce, summarize, classify, or extract the context first.
- Before Local LLM: ask whether a simple local command or direct inspection would be cheaper and more reliable.
- Before Main Agent Direct: ask whether the task is large enough that a preprocessing artifact would prevent repeated cloud context spending.
- Prefer reusable artifacts over repeated model calls.
