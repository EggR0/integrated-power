param(
    [Parameter(Mandatory = $true)]
    [string]$PromptFile,

    [string]$OutputFile = "",

    [string]$Endpoint = "",

    [string]$Model = "",

    [string]$SystemPrompt = "You are a helpful AI coding assistant.",

    [int]$MaxTokens = 2048,

    [double]$Temperature = 0.2,

    [int]$TimeoutSeconds = 1800,

    [string]$TaskTitle = "vLLM Inference",

    [string]$TaskScale = "Medium"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

function Write-Utf8NoBom {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Text
    )

    $dir = Split-Path -Parent $Path
    if (![string]::IsNullOrWhiteSpace($dir)) {
        New-Item -ItemType Directory -Force -Path $dir | Out-Null
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Text, $utf8NoBom)
}

function Invoke-CurlJson {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    $output = & curl.exe @Arguments 2>&1
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0) {
        throw "curl.exe failed with exit code $exitCode`: $output"
    }

    if ([string]::IsNullOrWhiteSpace($output)) {
        throw "curl.exe returned an empty response."
    }

    return ($output | ConvertFrom-Json)
}

function Get-FirstModelId {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ModelsUrl,

        [string]$ApiKey = ""
    )

    $args = @("-sS", "--max-time", "5", $ModelsUrl)
    if (![string]::IsNullOrWhiteSpace($ApiKey)) {
        $args += @("-H", "Authorization: Bearer $ApiKey")
    }

    try {
        $models = Invoke-CurlJson -Arguments $args
        if ($models.data -and $models.data.Count -gt 0 -and $models.data[0].id) {
            return [string]$models.data[0].id
        }
    }
    catch {
        throw "Unable to auto-detect a vLLM model from $ModelsUrl. Pass -Model explicitly. $($_.Exception.Message)"
    }

    throw "Unable to auto-detect a vLLM model from $ModelsUrl. Pass -Model explicitly."
}

function Resolve-OpenAIBaseUrl {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Endpoint
    )

    $baseUrl = $Endpoint.TrimEnd("/")
    if ($baseUrl -notmatch "/v1$") {
        $baseUrl = "$baseUrl/v1"
    }

    return $baseUrl
}

$repoRoot = ""
try {
    $gitRoot = (& git rev-parse --show-toplevel 2>$null)
    if ($LASTEXITCODE -eq 0 -and ![string]::IsNullOrWhiteSpace($gitRoot)) {
        $repoRoot = ($gitRoot | Select-Object -First 1).Trim()
    }
}
catch {
    $repoRoot = ""
}

if ([string]::IsNullOrWhiteSpace($repoRoot)) {
    $repoRoot = (Get-Location).Path
}

Import-Module (Join-Path $repoRoot "scripts\util\GlobalStorage.psm1") -DisableNameChecking
$storagePath = Get-GlobalStorage -RepoRoot $repoRoot

if ([string]::IsNullOrWhiteSpace($Endpoint)) {
    if (![string]::IsNullOrWhiteSpace($env:VLLM_BASE_URL)) {
        $Endpoint = $env:VLLM_BASE_URL
    }
    else {
        $Endpoint = "http://localhost:8000/v1"
    }
}

$baseUrl = Resolve-OpenAIBaseUrl -Endpoint $Endpoint
$modelsUrl = "$baseUrl/models"
$chatUrl = "$baseUrl/chat/completions"
$apiKey = $env:VLLM_API_KEY

if ([string]::IsNullOrWhiteSpace($Model)) {
    $Model = Get-FirstModelId -ModelsUrl $modelsUrl -ApiKey $apiKey
}

$promptPath = Resolve-Path -LiteralPath $PromptFile
$prompt = [string](Get-Content -Raw -Encoding UTF8 -LiteralPath $promptPath)

if ([string]::IsNullOrWhiteSpace($OutputFile)) {
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $OutputFile = Join-Path $storagePath "reports\vllm-$stamp.md"
}

$outputPath = if ([System.IO.Path]::IsPathRooted($OutputFile)) {
    $OutputFile
}
else {
    Join-Path $repoRoot $OutputFile
}

$bodyObject = [pscustomobject]@{
    model       = [string]$Model
    messages    = @(
        [pscustomobject]@{
            role    = "system"
            content = [string]$SystemPrompt
        },
        [pscustomobject]@{
            role    = "user"
            content = [string]$prompt
        }
    )
    stream      = $false
    max_tokens  = [int]$MaxTokens
    temperature = [double]$Temperature
}
$body = $bodyObject | ConvertTo-Json -Depth 10

$startedAt = Get-Date
$tempJsonFile = [System.IO.Path]::GetTempFileName()

try {
    Write-Utf8NoBom -Path $tempJsonFile -Text $body

    $curlArgs = @(
        "-sS",
        "--max-time", [string]$TimeoutSeconds,
        "-X", "POST",
        $chatUrl,
        "-H", "Content-Type: application/json",
        "-d", "@$tempJsonFile"
    )

    if (![string]::IsNullOrWhiteSpace($apiKey)) {
        $curlArgs += @("-H", "Authorization: Bearer $apiKey")
    }

    Write-Host "Sending prompt to vLLM ($Model) at $chatUrl..."
    $response = Invoke-CurlJson -Arguments $curlArgs
}
finally {
    Remove-Item -LiteralPath $tempJsonFile -ErrorAction SilentlyContinue
}

$endedAt = Get-Date
$elapsed = ($endedAt - $startedAt).TotalSeconds

if ($response.error) {
    $message = if ($response.error.message) { $response.error.message } else { ($response.error | ConvertTo-Json -Depth 10) }
    throw "vLLM returned an error: $message"
}

$content = $null
if ($response.choices -and $response.choices.Count -gt 0) {
    if ($response.choices[0].message -and $null -ne $response.choices[0].message.content) {
        $content = [string]$response.choices[0].message.content
    }
    elseif ($null -ne $response.choices[0].text) {
        $content = [string]$response.choices[0].text
    }
}

if ($null -eq $content) {
    throw "vLLM response did not include choices[0].message.content."
}

Write-Utf8NoBom -Path $outputPath -Text $content

$promptTokens = if ($response.usage -and $response.usage.prompt_tokens) { [int]$response.usage.prompt_tokens } else { 0 }
$completionTokens = if ($response.usage -and $response.usage.completion_tokens) { [int]$response.usage.completion_tokens } else { 0 }
$totalTokens = if ($response.usage -and $response.usage.total_tokens) { [int]$response.usage.total_tokens } else { $promptTokens + $completionTokens }

$metricsFile = Join-Path $storagePath "reports\token_usage.csv"
$metricsDir = Split-Path -Parent $metricsFile
if (![string]::IsNullOrWhiteSpace($metricsDir)) {
    New-Item -ItemType Directory -Force -Path $metricsDir | Out-Null
}

$row = [pscustomobject]@{
    Timestamp             = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Workspace             = if ($repoRoot) { Split-Path -Leaf $repoRoot } else { "Unknown" }
    WorkspacePath         = $repoRoot
    Operation             = "vLLM-Inference"
    Method                = "vllm-openai-compatible"
    Model                 = $Model
    WordCount             = 0
    CharCount             = 0
    Utf8Bytes             = 0
    InputTokens           = $promptTokens
    CachedInputTokens     = 0
    OutputTokens          = $completionTokens
    ReasoningOutputTokens = 0
    TotalTokens           = $totalTokens
    EstimatedTokens       = $totalTokens
    Confidence            = if ($totalTokens -gt 0) { "exact" } else { "unknown" }
    Source                = $outputPath
}

$retries = 3
for ($i = 0; $i -lt $retries; $i++) {
    try {
        if (Test-Path -LiteralPath $metricsFile) {
            $row | Export-Csv -NoTypeInformation -Encoding UTF8 -Append -LiteralPath $metricsFile
        }
        else {
            $row | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $metricsFile
        }
        break
    }
    catch {
        if ($i -eq ($retries - 1)) { throw }
        Start-Sleep -Milliseconds 1000
    }
}

$localMetricsFile = Join-Path $storagePath "reports\local_llm_metrics.csv"
$localRow = [pscustomobject]@{
    Timestamp            = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    TaskTitle            = $TaskTitle
    Model                = $Model
    TaskScale            = $TaskScale
    ActualElapsedSeconds = [math]::Round($elapsed, 2)
    TotalTokens          = $totalTokens
}

for ($i = 0; $i -lt $retries; $i++) {
    try {
        if (Test-Path -LiteralPath $localMetricsFile) {
            $localRow | Export-Csv -NoTypeInformation -Encoding UTF8 -Append -LiteralPath $localMetricsFile
        }
        else {
            $localRow | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $localMetricsFile
        }
        break
    }
    catch {
        if ($i -eq ($retries - 1)) { throw }
        Start-Sleep -Milliseconds 1000
    }
}

Write-Host "vLLM final message: $outputPath"
Write-Host "vLLM ($Model) completed in $([math]::Round($elapsed, 2))s. Total Tokens: $totalTokens"
