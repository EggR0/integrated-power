---
name: ai-orchestrator
description: Unified global skill for delegating tasks to AI models (Codex, Antigravity CLI, Local LLMs). Triggered by "use Codex", "use Antigravity CLI", "run local LLM", or similar.
---

# AI Orchestrator

This is the primary routing skill for invoking AI models. When the user asks to "use Codex" (or similar), use this skill to classify the task and dispatch it to the correct execution mode.

## Mode Classification (Routing)

Always read the detailed contract in the `references/` directory before executing a mode.

1. **Debate Mode (`scripts/Invoke-CodexDebate.ps1`)**:
   - **Trigger**: Architecture decisions, ADRs, tradeoff reviews, second opinions, read-only critique.
   - **Action**: Generates a persistent human-readable Markdown transcript.
   - **Contract**: Read `references/debate.md`.

2. **Job Mode (`scripts/Invoke-CodexJob.ps1`)**:
   - **Trigger**: Bounded implementation, massive refactoring, automated test generation, or tasks that need to overwrite/create files directly without an ongoing conversation.
   - **Action**: Executes the prompt and saves the result directly, skipping human chat loops.
   - **Contract**: Read `references/job.md`.

3. **WorkWindow Mode (`scripts/Invoke-AiWorkWindow.ps1`)**:
   - **Trigger**: Longer supervised coding sessions, processing the `ai-work-queue.md`, iterative execution across multiple tasks, or high-level context coordination.
   - **Action**: Aggregates the local queue, calendar, and context into a single mega-prompt for Codex.
   - **Contract**: Read `references/workwindow.md`.

## Execution Timer and Metrics Guidelines

When you dispatch a task to Codex using one of the background scripts above, the scripts will run their own native **Watchdog Loop** using `System.Diagnostics.Process` to enforce safe execution and pure UTF-8 logging.

Follow these explicit rules:
1. **Required Completion Sentinel**: You MUST explicitly tell Codex in your prompt: "When you are completely finished with all work, output exactly the phrase `CODEX_JOB_DONE status=success` at the very end of your response."
2. **Estimate Task Scale**: Before setting your timer, estimate the scale of the task (e.g., 'Small Refactor', 'Medium Feature').
3. **Wait for Completion**: Use the `schedule` tool to set a long wait timer. You do NOT need to poll. The script's watchdog will automatically kill Codex if it gets stuck *after* outputting the sentinel (`completed_stuck`), or if it completely idles for 10 minutes (`idle_timeout`).
4. **Execution Time Feedback Loop (Metrics)**: 
   - When the background script completes, observe the actual elapsed time.
   - You MUST also retrieve the total tokens used by Codex for this job. You can find this by checking the last entry in `<repo-root>/operational-data/reports/codex_usage.csv` (the script automatically parses usage if `-JsonLog` is used, so always pass `-JsonLog $true` if you need token counts).
   - Record the mapping of `[Timestamp, Mode, Task Scale, Estimated Wait, Actual Elapsed Time, Total Tokens]` into a persistent metrics log located at `<repo-root>/operational-data/reports/codex_timer_metrics.csv` (create it if it doesn't exist).
   - Use this historical data CSV to continually improve your timer estimates and to compare token usage against task scale in future invocations.

## General Rules

- Do NOT pass repository file contents directly inside prompts when dispatching. Always pass file paths (e.g. `-ContextFile`) or let Codex use its sandbox to read them.
- Ensure you select the appropriate `-Sandbox` permissions (`read-only`, `workspace-write`, `danger-full-access`).

## Codex Installation & Executable Resolution

This plugin automatically resolves the path to the Codex executable. By default, it checks:
1. System `PATH`.
2. `$env:CODEX_EXE`
3. Local AppData installations (`%LOCALAPPDATA%\OpenAI\Codex\bin\*\codex.exe`)
4. Interactive console prompt if not found.

If a user complains that Codex isn't running, advise them to either add Codex to their PATH, set the `CODEX_EXE` environment variable, or run the command directly to be prompted for the path.
