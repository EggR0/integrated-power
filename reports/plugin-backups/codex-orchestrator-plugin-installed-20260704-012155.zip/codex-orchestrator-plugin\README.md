# Codex Orchestrator Plugin

This Antigravity Plugin globally installs the **Codex Orchestrator** environment.
It provides robust background delegation to OpenAI Codex via Job mode, Debate mode, and WorkWindow queueing.

## Installation
1. Drop this folder (`codex-orchestrator-plugin`) into `~/.gemini/config/plugins/`.
2. Ensure you have the `codex.exe` CLI installed either globally on your `PATH`, or set `$env:CODEX_EXE`. The plugin will also attempt to auto-detect installations inside `%LOCALAPPDATA%\OpenAI\Codex\bin`. If it still cannot find it, it will prompt you interactively in the console.

## Global Routing Rules (Optional)
To ensure Antigravity automatically uses this plugin for large architectural decisions and refactors, you should append the recommended routing rules to your `~/.gemini/GEMINI.md` file. 

You can do this automatically by running:
```powershell
& "~/.gemini/config/plugins/codex-orchestrator-plugin/install/Add-GlobalRules.ps1"
```

## Features
- **Watchdog Protection**: Jobs run in the background with a strict UTF-8 stream encoder and a hang-protection watchdog.
- **Portability**: Auto-resolves Codex binary locations.
- **Debate Mode**: Transparent reasoning with cross-model criticism.
