param(
    [string]$Mode,
    [datetime]$StartedAt,
    [datetime]$EndedAt,
    [string]$ExitCode,
    [string]$JsonLogPath,
    [string]$Model,
    [string]$TaskScale = "",
    [string]$EstimatedWait = "",
    [string]$RepoRoot
)

$ErrorActionPreference = "Continue"

try {
    $elapsed = ($EndedAt - $StartedAt).TotalSeconds
    $elapsedStr = "{0:N2}" -f $elapsed

    $totalTokens = 0
    if (-not [string]::IsNullOrWhiteSpace($JsonLogPath) -and (Test-Path -LiteralPath $JsonLogPath)) {
        foreach ($line in [System.IO.File]::ReadLines($JsonLogPath)) {
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            try {
                $event = $line | ConvertFrom-Json
                if ($event.type -eq "turn.completed" -and $null -ne $event.usage) {
                    $totalTokens += [int64]$event.usage.input_tokens + [int64]$event.usage.output_tokens
                }
            } catch {}
        }
    }

    $metricsFile = Join-Path $RepoRoot "operational-data\reports\codex_timer_metrics.csv"
    $metricsDir = Split-Path -Parent $metricsFile
    if (-not (Test-Path -LiteralPath $metricsDir)) {
        New-Item -ItemType Directory -Force -Path $metricsDir | Out-Null
    }

    $metric = [pscustomobject]@{
        Timestamp = $StartedAt.ToString("yyyy-MM-dd HH:mm:ss")
        Mode = $Mode
        TaskScale = $TaskScale
        EstimatedWait = $EstimatedWait
        ActualElapsedTimeSeconds = $elapsedStr
        TotalTokens = $totalTokens
        Model = $Model
        Status = $ExitCode
    }

    if (-not (Test-Path -LiteralPath $metricsFile)) {
        $metric | Export-Csv -NoTypeInformation -Encoding UTF8 -LiteralPath $metricsFile
    } else {
        $metric | Export-Csv -NoTypeInformation -Encoding UTF8 -Append -LiteralPath $metricsFile
    }
} catch {
    Write-Warning "Failed to write Codex timer metrics: $_"
}
